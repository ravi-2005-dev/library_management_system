import axios from "axios"
import { useState } from "react"
import { useNavigate } from "react-router-dom"

function Login(){
    const navigate=useNavigate()
    const [form,setform]=useState(
        {
            username:"",
            password:""
        }
    )
    const changedata = (e) =>{
        setform({...form,[e.target.name]:e.target.value})
    }
    const submitform = async (e) =>
        {
        e.preventDefault()
        console.log("step1");
        const response=await axios.post("http://localhost:4678/login",form)
        alert(response.data)
        console.log("step2");
        navigate("/admin")
    }
    
    return (
        <>
                <h1>i am login</h1>
                <form onSubmit={submitform}>
                    <input onChange={changedata} type="text" name="username" placeholder="enter username"/><br/>
                    <input onChange={changedata} type="password" name="password" placeholder="enter password"/><br/>
                    <button type="submit">login</button>
                </form>
        </>
    )
}
export default Login