import { Link } from "react-router-dom"
import Library from "./Library"
import Admin from "./Admin"

function Home(){
    return (
        <>

        <h1>hi iam home</h1>
        <Link to="/reg">click here to register</Link><br/>
        <Link to="/log">click here to login</Link><br/>
        
        </>
    )
}
export default Home