import axios from "axios"
import { useState } from "react"

function Register(){
    const [form,setform]=useState(
        {
            username:"",
            email:"",
            password:""
        }
    )
    const changedata = (e) =>{
        setform({...form,[e.target.name]:e.target.value})
    }
    const submitform = async (e) =>
        {
        e.preventDefault()
        console.log("step1")
        const response=await axios.post("http://localhost:4678/register",form)
        console.log("step2")
        alert(response.data)
    }
    
    return (
        <>
                <h1>i am register</h1>
                <form onSubmit={submitform}>
                    <input onChange={changedata} type="text" name="username" placeholder="create username"/><br/>
                    <input  onChange={changedata} type="email" name="email" placeholder="create mail"/><br/>
                    <input onChange={changedata} type="password" name="password" placeholder="create password"/><br/>
                    <button type="submit">Register</button>
                </form>
        </>
    )
}
export default Register;