import axios from "axios"
import { useState } from "react"

function AuthorBook(){
    const [form,setform]=useState("")
    const [result,setresult]=useState([])

    const changedata = (e) =>{
            setform(e.target.value)
    }
    const submitform = async (e) =>
        {
        e.preventDefault()
        const response=await axios.get(`http://localhost:4678/book/authorform/${form}`)
            setresult(response.data)
    }
    
    return (
        <>
                <h1>add a book</h1>
                <form onSubmit={submitform}>
            
                    <input  onChange={changedata} type="text" name="author" placeholder="enter author name"/><br/>
                   
                    <button type="submit">search book</button>
                </form>
                {
                     result.map(x =>(
                <li>
                    {x.title}  {x.author} {x.description}
                </li>
            ))
        }
        </>
    )
}
export default AuthorBook;