import axios from "axios"
import { useEffect, useState } from "react"

function Viewall() {
    const [books, setBooks] = useState([])
    const [page, setPage] = useState(0)
    const [totalPages, setTotalPages] = useState(0)

    const fetchBooks = async (pageNumber) => {
        try {
            const response = await axios.get(`http://localhost:4678/book/?page=${pageNumber}&size=5`)
            setBooks(response.data.content)
            setTotalPages(response.data.totalPages)
            setPage(response.data.number)
        } catch (error) {
            console.error('Error fetching books', error)
        }
    }

    useEffect(() => {
        fetchBooks(page)
    }, [page])

    const handleBack = () => {
        if (page > 0) {
            setPage(page - 1)
        }
    }

    const handleNext = () => {
        if (page + 1 < totalPages) {
            setPage(page + 1)
        }
    }

    return (
        <>
            <h1>View All Books</h1>
            <button onClick={handleBack} disabled={page === 0}>Back</button>
            <button onClick={handleNext} disabled={page + 1 >= totalPages}>Next</button>
            <ul>
                {books.map((b) => (
                    <li key={b.id}>{b.title} - {b.author}</li>
                ))}
            </ul>
        </>
    )
}

export default Viewall
