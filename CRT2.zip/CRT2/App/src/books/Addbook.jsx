import axios from "axios"
import { useState } from "react"

function AddBook(){
    const [form,setform]=useState(
        {
            title:"",
            author:"",
            description:""
        }
    )
    const changedata = (e) =>{
        setform({...form,[e.target.name]:e.target.value})
    }
    const submitform = async (e) =>
        {
        e.preventDefault()
        try{
        const response=await axios.post("http://localhost:4678/book/addbook",form)
        alert(response.data)
    }
    catch(error){
        if(error.response && error.response.status===409){
            console.log(error)
            console.log(error.response.data)
            console.log()
        }
        else{
    
        }
    }
    }
    
    return (
        <>
                <h1>add a book</h1>
                <form onSubmit={submitform}>
                    <input onChange={changedata} type="text" name="title" placeholder="enter title"/><br/>
                    <input  onChange={changedata} type="text" name="author" placeholder="enter author name"/><br/>
                    <input onChange={changedata} type="text" name="description" placeholder="write about book"/><br/>
                    <button type="submit">add book</button>
                </form>
        </>
    )
}
export default AddBook;