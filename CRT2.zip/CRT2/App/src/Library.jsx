import axios from "axios";
import { useState } from "react";
import { Link } from "react-router-dom";

function Library() {
    const [result, setResult] = useState([]);

    const viewallbooks = async (e) => {
        e.preventDefault();
        try {
            const response = await axios.get("http://localhost:4678/book/all");
            setResult(response.data);
        } catch (error) {
            console.error("Error fetching books:", error);
        }
    };

    return (
        <>
            <h1>You are at the Library....</h1>
            <Link to="/abook">add book</Link><br />
            <button onClick={viewallbooks}>view all books</button><br />
            <Link to="/vauthorbook">author</Link><br />
            <Link to="/viewall">click here to see pages</Link><br />
            <ul>
                {result.map((x) => (
                    <li key={x.id}>
                        {x.title} {x.author} {x.description}
                    </li>
                ))}
            </ul>
        </>
    );
}

export default Library;
