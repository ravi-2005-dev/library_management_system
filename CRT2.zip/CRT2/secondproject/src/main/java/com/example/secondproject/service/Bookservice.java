package com.example.secondproject.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import com.example.secondproject.model.Book;
import com.example.secondproject.repository.BookRepository;

@Service
public class Bookservice {

    @Autowired
    private BookRepository br;

    @Cacheable("hii")
    public List<Book> getBook(String name) {
        try {
            // Simulate processing delay (e.g., calling external API or long DB query)
            Thread.sleep(10000); // sleep for 1 second

            return br.findByAuthor(name);
        } catch (InterruptedException e) {
            // Restore the interrupted status
            Thread.currentThread().interrupt();

            // Optionally wrap and rethrow as unchecked
            throw new RuntimeException("Thread was interrupted while fetching books", e);
        }
    }
}
