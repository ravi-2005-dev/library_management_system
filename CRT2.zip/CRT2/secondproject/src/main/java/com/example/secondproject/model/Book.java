package com.example.secondproject.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Book{
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
int id;
@Column
String title;
@Column
String author;
@Column
String description;
public void setAuthor(String name){
    this.author = name;
}
public void setDescription(String name){
    this.description = name;
}
public void setTile(String name){
    this.title = name;
}
public String getAuthor(){
    return this.author;
}
public String getTitle(){
    return this.title;
}
public String getDescription(){
    return this.description;
}
}
