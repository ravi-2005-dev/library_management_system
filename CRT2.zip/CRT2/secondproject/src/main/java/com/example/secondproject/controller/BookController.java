package com.example.secondproject.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.secondproject.model.Book;
import com.example.secondproject.repository.BookRepository;
import com.example.secondproject.service.Bookservice;

@RestController
@RequestMapping("/book")
@CrossOrigin(origins = "http://localhost:5173")
public class BookController {

    @Autowired
    private BookRepository br;

    @Autowired
    Bookservice b;


    @PostMapping("/addbook")
    public ResponseEntity<?> addbook(@RequestBody Book b) {
        Book result = this.br.findByTitle(b.getTitle());
        if (result != null) {
            return ResponseEntity.status(HttpStatus.CONFLICT).body("The book already exists");
        }
        br.save(b);
        return ResponseEntity.status(HttpStatus.CREATED).body("Book successfully added");
    }

    @GetMapping("/all")
    public List<Book> viewAll() {
        return this.br.findAll();
    }

    @GetMapping("/authorform/{name}")
    public List<Book> viewByAuthor(@PathVariable String name) {
        List<Book> result= this.b.getBook(name);
        return result;
    }

    @GetMapping("/")
    public ResponseEntity<Page<Book>> getBooks(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "5") int size) {
        Pageable p = PageRequest.of(page, size);
        Page<Book> booksPage = this.br.findAll(p);
        return ResponseEntity.ok(booksPage);
    }
}
